from flask import Flask, jsonify, request, abort,url_for,render_template,redirect
from time import time
from bson.objectid import ObjectId
from bson.json_util import dumps
from flask_pymongo import PyMongo
app = Flask(__name__)
app.config['MONGO_DBNAME'] = 'yu'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/yu'
app.url_map.strict_slashes = False
mongo = PyMongo(app)

@app.route("/", methods=['GET'])
def index():
    data = mongo.db.yu.find({})
    return  render_template('index.html',data=data)


@app.route('/add', methods=['POST'])
def add():
    content = request.form.get('content', None)
    address = request.form.get('address', None)
    contact = request.form.get('contact', None)
    mongo.db.yu.insert({"content":content,"address":address,"contact":contact})
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)